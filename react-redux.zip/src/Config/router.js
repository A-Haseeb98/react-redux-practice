import { BrowserRouter as Router, Switch, Route} from "react-router-dom";
import ChildOne from '../Components/child1.js/child1'
import ChildTwo from '../Components/child2.js/child2'
import ChildThree from '../Components/childThree/child3'

function AppRouter(){
    return(
        <Router>
            <Switch>
                <Route exact path='/' component={ChildOne}/>
                <Route exact path='/two' component={ChildTwo}/>
                <Route exact path='/three' component={ChildThree}/>
            </Switch>
        </Router>
    )
}

export default AppRouter