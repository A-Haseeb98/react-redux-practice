import ChildTwo from "../child2.js/child2"
import { Link } from 'react-router-dom'
import { useSelector } from "react-redux"
function ChildOne() {
    const store = useSelector(state => state)
    console.log(store, 1)
    return (
        <div>
            children 1
            <br />
            <h2>{store.user.name}</h2>
            <Link to='/two' > link to child 2</Link>
            <br/>
            <Link to='/three' > link to child 3</Link>

        </div>

    )
}

export default ChildOne