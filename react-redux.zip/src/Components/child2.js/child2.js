import ChildThree from '../childThree/child3.js'
import {Link} from 'react-router-dom'
import {useSelector} from 'react-redux'

function ChildTwo(){
    const store = useSelector(store => store)
    console.log('2',store)
    return(
        <div>
            children 2 <br/>
            <h2>{store.user.name}</h2>

            <Link to='/'>link to home</Link>
            <br/>
            <Link to='/three'>link to childe3</Link>

        </div>
    )
}

export default ChildTwo