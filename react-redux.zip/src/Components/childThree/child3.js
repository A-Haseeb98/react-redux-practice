import {Link} from 'react-router-dom'
import {useSelector,useDispatch} from 'react-redux'
import Button from '@restart/ui/esm/Button'

function ChildThree(){

const store = useSelector(state => state)
const dispatch = useDispatch()
console.log(store,3)
    return(
        <div>
            children 3
            <br/>
            <h2>{store.user.name}</h2>
            <button onClick={()=> dispatch({type: 'Test', name: 'muneeb'})} >Haseeb</button>

            <Link to='/'>go to home</Link>
        </div>
    )
}

export default ChildThree;