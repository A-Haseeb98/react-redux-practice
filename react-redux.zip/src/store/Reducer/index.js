const INITIAL_STATE = {
    user:{
        name: 'haseeb',
      
    }
}

const reducer = (state = INITIAL_STATE, action)=>{
  
    switch(action.type){
        case "Test":
        return{
            ...state,
            name : action.name
        }
        default:
            return state;
    }

}

export default reducer;