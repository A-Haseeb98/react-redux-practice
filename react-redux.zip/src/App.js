import './App.css';
import ChildOne from './Components/child1.js/child1';
import { Provider } from 'react-redux';
import store from './store';
import AppRouter from './Config/router'
function App() {
  return (
    <Provider store={store} >
      <AppRouter />
    </Provider>
  )
}
export default App;
